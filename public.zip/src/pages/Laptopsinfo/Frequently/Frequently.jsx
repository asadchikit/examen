import React from 'react'
import "./frequently.css"
import Skroll from '../Skrollbar/Skroll'
function Frequently() {
    return (
        <div>
            
            <h1 className='frequently'>Frequently bought together</h1>
            <Skroll/>
        </div>
    )
}

export default Frequently